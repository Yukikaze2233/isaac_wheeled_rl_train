RUN='/home/kaiser/robot-rl-sim60/experiments/v6-task-campaign-20261001T110045Z-282358'
BASE='/home/kaiser/robot-rl-sim60'
SESSION='v6-task-campaign-20261001T110045Z-282358-r19'
META={'schema': 'task-source-repair-019-candidate-v1', 'status': 'frozen_not_deployed', 'source_commit': '712d701473f38ef6797725f8efdda9e6beb85e87', 'previous_source_commit': '4ba339299c203cf2aba77183ec81f2f017dc9bf9', 'archive_local': '/home/yukikaze/Documents/workspace/robot_rl/isaac_wheeled_rl_schedule/reports/v6_scut_posture_completion_20261006/source_repair_019/source_712d701473f3.tar.gz', 'archive_sha256': 'fb5172d1f2a44aaf556f52e5de389cd59f5a3ef7bed79919b68d4d7c6580d247', 'archive_size_bytes': 88939008, 'clean_root': '/tmp/scut-ordinary-alias-019-oit43rqd', 'source_remote': '/home/kaiser/robot-rl-sim60/experiments/v6-task-campaign-20261001T110045Z-282358/source_712d701473f3', 'archive_remote': '/home/kaiser/robot-rl-sim60/experiments/v6-task-campaign-20261001T110045Z-282358/source_712d701473f3.tar.gz', 'plan_sha256': '027de0e63832b3821d7a1686e8bbc3e1a2662094476c06c3f71193fed59ec022', 'manifest_sha256': '207280abb8a0fbde7370ef78ab0c0e7ca86c4959a50044c115aac48347d399a9', 'contract_file': 'contracts/v6_task_campaign_v18.json', 'worker_hashes': {'recovery': '7b5ecc7acc6871e072c2ca131d2ad2fa169dfd321b8a6c875cf2df643c5fd013', 'speed': '42d41d69b6040c0cc550bf8c65bcbfbc369e7f9efec280e2b71b942918ca0090', 'terrain': 'd3c0658b7b5b51aa89fc08d1503e91ae57a4682173bcb076bdbd4d83ede3f611', 'jump': '1f148d9ac6a09d66694c63acef7ae869277129fb9fea342c8c4c5b581d8a4c64', 'stepjump': '4b3c3708b317d5174a963de95d4234d89ab295158994fc01b6d9e44e6618ecb4'}, 'changed_runtime_files': {'src/wheeled_tasks/chassis/env.py': {'previous': '0e5b0ae5ea6d443d567bb8b45055d967f56c1be5fde1f2a21e8b69d285e10c4b', 'candidate': 'a0eeb8da7a406aa79f8103f2857fa97ee36585a2bfddc1246fa0599b50c48cf3'}, 'src/wheeled_tasks/chassis/ordinary_posture_curriculum.py': {'previous': '49add13707926965fdfdcc0dcada12860c6f84525fa5e6683cdc3d8fecea6a50', 'candidate': 'b3424cf23f9d7afec294ad00576d8fc2f8c9de4f2d3560df3bb852c46f9a4dff'}}, 'ordinary_population_expected': {'recovery': 1449, 'speed': 3928, 'terrain': 4096, 'jump': 1231, 'stepjump': 1228}, 'mechanism_change': '872 existing recovery motion rehearsal lanes gain ordinary root tilt and gentle push; recovery has no nonstandard leg bank', 'same_contract_resume': 'preserve all full learning state, consumption and origins; zero new critic warmup', 'qualified': None}
EVIDENCE_SHA={'source_candidate': '559764b6100c57d786bb9f178b0a7ce8a7fbf81aaf61cc3d8879b5997eb40380', 'clean_tests': '4c31b261169a2b9efdb4f54c51766f76fa41cd4a16fcc7161ecd5cb731b1c1cb', 'clean_30_roles': 'a7e3fa5c1900640dfc44a5f1d7b49c047e926428e5d7d2300d0bdfa5d9c695ce', 'native_recovery': '07b4b9af55a0f1d99849ba89820a12eef3ea8769fc7b7a3d9588cb31b23f24ea'}

import hashlib,json,pathlib,sys
r=pathlib.Path(RUN);src=pathlib.Path(META['source_remote'])
def read(p):return json.loads(p.read_text())
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024**2),b''):h.update(b)
 return h.hexdigest()
def entry(argv):
 for value in argv[1:]:
  if value in (b'-c',b'-m'):return None
  if value.endswith(b'.py'):return pathlib.Path(value.decode())
 return None
def owners():
 result=[]
 for p in pathlib.Path('/proc').glob('[0-9]*/cmdline'):
  try:
   argv=p.read_bytes().split(b'\0');script=entry(argv)
   if script and script.name in ('run_task_campaign.py','train_chassis.py','evaluate_chassis.py','chassis_remote_job.py') and any(x==str(r).encode() or x==str(r/'train').encode() or x.startswith(str(r/'train').encode()+b'/') for x in argv):result.append(dict(pid=int(p.parent.name),command=[x.decode() for x in argv if x]))
  except (OSError,PermissionError):pass
 return result
sys.path.insert(0,str(src/'src'));sys.path.insert(0,str(src/'scripts'))
from chassis_remote_job import validate_source_revision
from wheeled_tasks.chassis.full_curriculum import checkpoint_update_count,checkpoint_contract_path
from wheeled_tasks.chassis.task_campaign import account_updates,validate_task_resume
def latest(domain):
 candidates=[]
 for p in (r/'train'/domain).glob('attempt_*/train/**/*.checkpoint.json'):
  if any(part.endswith('.pending') for part in p.parts):continue
  seal=read(p);cp=p.with_suffix('').with_suffix('.pt')
  assert type(seal.get('learning_updates')) is int and seal['learning_updates']>=0
  candidates.append((seal['learning_updates'],cp.name=='model_final.pt',cp))
 return max(candidates,key=lambda item:item[:2])[2] if candidates else None
def parents(plan):
 result={}
 for row in plan['domains']:
  domain=row['name'];cp=latest(domain)
  if cp is None:
   assert domain=='stepjump','Existing domain lost all sealed parents'
   continue
  seal_path=cp.with_suffix('.checkpoint.json');seal=read(seal_path)
  contract=checkpoint_contract_path(cp)
  assert cp.resolve().is_relative_to((r/'train'/domain).resolve())
  assert seal['sealed'] is True and seal['task_campaign']['domain']==domain
  assert checkpoint_update_count(cp)==seal['learning_updates']
  assert sha(cp)==seal['checkpoint_sha256'] and sha(contract)==seal['contract_sha256']
  # Older unvisited domains retain their own older worker state and migrate
  # through the already-frozen v18 path when the existing campaign reaches them.
  validate_task_resume(read(contract),read(src/row['contract']))
  result[domain]=dict(path=str(cp),sha256=sha(cp),seal=seal,seal_sha256=sha(seal_path),contract=str(contract),contract_sha256=sha(contract))
 return result
def authenticate_quiescent():
 job=read(r/'job.json');assert not pathlib.Path('/proc/'+str(job['pid'])+'/cmdline').exists(),'Former supervisor still live'
 assert not owners(),'Live campaign worker/wrapper/supervisor or orphan'
 old=pathlib.Path(RUN)/'source_4ba339299c20'
 oldrevision=read(r/'source_revision_018.json')
 assert oldrevision['source_commit']==META['previous_source_commit'] and pathlib.Path(oldrevision['new_source_root'])==old
 cmd=job['command']
 assert cmd.count(str(old/'scripts/run_task_campaign.py'))==1
 assert cmd.count('--contract')==cmd.count('--run-dir')==1
 assert pathlib.Path(cmd[cmd.index('--contract')+1])==old/'contracts/v6_task_campaign_v18.json'
 assert pathlib.Path(cmd[cmd.index('--run-dir')+1])==r/'train'
 assert sha(old/'contracts/v6_task_campaign_v18.json')==sha(src/'contracts/v6_task_campaign_v18.json')==META['plan_sha256']
 # Source-only means every existing contract stays byte-for-byte identical.
 oldcontracts={str(p.relative_to(old)):sha(p) for p in (old/'contracts').rglob('*') if p.is_file()}
 newcontracts={str(p.relative_to(src)):sha(p) for p in (src/'contracts').rglob('*') if p.is_file()}
 assert oldcontracts==newcontracts,'Source repair changed contract bytes or catalogue'
 state=read(r/'train/campaign_state.json');account=read(r/'train/consumption.json');plan=read(src/'contracts/v6_task_campaign_v18.json')
 assert state['status']=='stopped'
 assert state['contract_sha256']==account['contract_sha256']==META['plan_sha256']
 assert account['rollback_refunds_consumed_updates'] is False and account['run_directory']==str(r/'train')
 calculated=account_updates(plan,account['attempts'])
 assert calculated=={k:account[k] for k in calculated}=={k:state[k] for k in calculated}
 # Recompute every reservation from persisted worker progress without writing.
 from wheeled_tasks.chassis.task_campaign import update_attempt
 replay=account['attempts']
 for p in (r/'train').glob('*/attempt_*/train/progress.json'):
  name=str(p.parent.relative_to(r/'train'));replay=update_attempt(plan,replay,name,p.parts[-4],read(p))
 assert replay==account['attempts'],'Final progress has uncharged work or stale account'
 bound=parents(plan);rec=bound['recovery'];cp=pathlib.Path(rec['path'])
 assert cp.name=='model_final.pt' and cp.parent==r/'train/recovery/attempt_002/train'
 completion=read(cp.parent/'completion.json');progress=read(cp.parent/'progress.json')
 assert completion['status']=='stopped' and completion['successful_updates']>0 and completion['actor_updates_in_block']>0
 assert completion['task_actor_update']==progress['task_actor_update']==rec['seal']['task_actor_update']>2294
 worker=next(row for row in plan['domains'] if row['name']=='recovery')
 assert rec['contract_sha256']==worker['sha256']==META['worker_hashes']['recovery']
 assert rec['seal']['learning_updates']<=account['consumed_updates'] and rec['seal']['actor_updates_consumed']<=account['actor_updates_consumed']
 import torch
 from train_chassis import resume_critic_warmup
 payload=torch.load(cp,map_location='cpu',weights_only=False);infos=payload['infos']
 assert all(payload.get(k) for k in ('actor_state_dict','critic_state_dict','optimizer_state_dict')),'Not full learning state'
 assert payload['optimizer_state_dict']['state'],'Missing restored Adam state'
 for key in ('stage_actor_update','task_actor_update','actor_updates_consumed','learning_lineage_updates'):
  assert infos[key]==rec['seal'][key]
 assert infos['successful_updates_total']==rec['seal']['learning_updates']
 assert infos['contract_sha256']==worker['sha256'] and infos['task_campaign']['domain']=='recovery'
 assert infos['critic_warmup_remaining']==resume_critic_warmup(read(src/worker['contract']),infos,contract_sha256=worker['sha256'],task_change=True)==0
 rec['authenticated_infos']={k:infos[k] for k in ('contract_sha256','successful_updates_total','stage_actor_update','task_actor_update','actor_updates_consumed','learning_lineage_updates','critic_warmup_remaining')}
 rec['completion_sha256']=sha(cp.parent/'completion.json');rec['progress_sha256']=sha(cp.parent/'progress.json')
 return job,state,account,bound,old

import fcntl,tempfile
from datetime import datetime,timezone
with (r/'source_repair_019.lock').open('a') as lock:
 fcntl.flock(lock.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not (r/'source_repair_launch_019.json').exists(),'Already dispatched; inspect'
 job,state,account,bound,old=authenticate_quiescent()
 command=list(job['command']);command[command.index(str(old/'scripts/run_task_campaign.py'))]=str(src/'scripts/run_task_campaign.py')
 command[command.index('--contract')+1]=str(src/'contracts/v6_task_campaign_v18.json')
 revision=dict(schema='task-source-revision-v1',previous_job_sha256=sha(r/'job.json'),command=command,
  source_commit=META['source_commit'],old_source_root=str(old),new_source_root=str(src),old_contract_sha256=META['plan_sha256'],new_contract_sha256=META['plan_sha256'],source_archive=META['archive_remote'],source_archive_sha256=META['archive_sha256'])
 with tempfile.NamedTemporaryFile(mode='w',dir=r,prefix='source_revision_019_validation_',suffix='.pending',delete=False) as f:
  json.dump(revision,f);pending=pathlib.Path(f.name)
 try:validate_source_revision(r,command,job,pending)
 finally:pending.unlink()
 predecessor=dict(schema='task-source-repair-predecessor-019-v1',prepared_at_utc=datetime.now(timezone.utc).isoformat(),source_commit=META['source_commit'],previous_source_commit=META['previous_source_commit'],evidence_sha256=EVIDENCE_SHA,job=job,campaign_state=state,consumption=account,
  file_sha256={name:sha(r/name) for name in ('job.json','train/campaign_state.json','train/consumption.json')},actual_parents=bound,expected_critic_warmup=0,qualification=None)
 proof=r/'predecessor_019.json'
 if proof.exists():
  prior=read(proof);assert all(prior[k]==predecessor[k] for k in predecessor if k!='prepared_at_utc')
 else:
  with proof.open('x') as f:json.dump(predecessor,f,indent=2);f.write(chr(10))
 path=r/'source_revision_019.json'
 if path.exists():assert read(path)==revision
 else:
  with path.open('x') as f:json.dump(revision,f,indent=2);f.write(chr(10))
 print(json.dumps(dict(status='prepared_same_v18_source_only',revision=revision,predecessor=read(proof))))

